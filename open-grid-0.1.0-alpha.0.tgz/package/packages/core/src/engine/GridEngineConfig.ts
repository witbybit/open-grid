import type { ColumnDef, GridStyleRule } from '../columnDef.js';
import type { GridCellPointer, GridSelectionState, RowSelectionOptions } from '../api/GridApi.js';
import type { RowValidator } from '../features/ValidationManager.js';
import type { BuiltInThemeName } from '../renderer/themes.js';
import type { SortModel, FilterModel } from '../rowModel.js';

export interface GridEngineConfig<TRowData = unknown> {
	columns: ColumnDef<TRowData>[];
	/** Enables first-class row node selection and configures built-in checkbox behavior. */
	rowSelection?: RowSelectionOptions;
	getRowId?: (row: TRowData) => string;
	rowHeights?: Record<string, number>;
	columnWidths?: Record<string, number>;
	defaultRowHeight?: number;
	defaultColWidth?: number;
	enableColumnReorder?: boolean;
	selection?: GridSelectionState;
	selectedRowIds?: string[];
	sortModel?: SortModel | null;
	filterModel?: FilterModel | null;
	themeName?: BuiltInThemeName;
	activeEdit?: GridCellPointer | null;
	loadingSkeletonCount?: number;
	styleRules?: GridStyleRule<TRowData>[];
	loading?: boolean;
	/**
	 * Grid-level cross-field validator. Runs after per-column valueValidators on every
	 * validateCell / validateGrid call. Return a map of colField → error string to set
	 * cross-field errors; return null/empty string for a field to clear its row-level error.
	 */
	rowValidator?: RowValidator<TRowData>;

	// Tree / Grouping / Master-Detail State Configuration
	groupBy?: string[];
	getParentId?: (row: TRowData) => string | null | undefined;
	masterDetailEnabled?: boolean;
	groupRowHeight?: number;
	detailRowHeight?: number;
	detailRenderer?: unknown;
	rowModelConfig?: import('../rowModel.js').RowModelConfig<TRowData>;
	showGroupFooter?: boolean;
	enableStickyGroupRows?: boolean;
	showGroupPanel?: boolean;
	showFilterChipBar?: boolean;
	showFloatingFilters?: boolean;
	showStatusBar?: boolean;
	pagination?: { pageSize: number; page?: number };
	expansion?: {
		groups: Record<string, true>;
		treeRows: Record<string, true>;
		details: Record<string, true>;
	};
	/**
	 * Pixel height of the pre-render buffer above and below the visible viewport.
	 * The grid renders all rows that overlap [visibleTop - rowOverscanPx, visibleBottom + rowOverscanPx],
	 * so the buffer is always a fixed pixel amount regardless of individual row heights.
	 * Default: 400px (roughly 10 rows at the default 40px row height).
	 */
	rowOverscanPx?: number;
	colBuffer?: number;
	runtimeLimits?: {
		maxRenderedRows?: number;
		maxRenderedCells?: number;
		suppressRenderedRangeLimit?: boolean;
	};
	/**
	 * When true, the overscan buffer automatically expands in the scroll direction proportional
	 * to scroll velocity, reducing blank-band flashes during fast scrolling.
	 * Default: false.
	 */
	overscanAdaptive?: boolean;
	/** Returns the host container element. Used by auto-size and any feature that needs DOM measurements. */
	getContainerElement?: () => HTMLElement | null;
}
