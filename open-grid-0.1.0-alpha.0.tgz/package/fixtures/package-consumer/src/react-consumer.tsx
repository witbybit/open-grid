import { Grid, type ColumnDef } from '@open-grid/react';

interface Row {
	id: string;
	name: string;
}

const columns: ColumnDef<Row>[] = [{ field: 'name', header: 'Name' }];
const rows: Row[] = [{ id: '1', name: 'Ada' }];

export function FixtureGrid() {
	return <Grid mode='client' rows={rows} columns={columns} getRowId={(row: Row) => row.id} />;
}
